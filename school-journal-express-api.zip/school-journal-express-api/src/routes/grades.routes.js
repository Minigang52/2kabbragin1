const express = require("express");
const router = express.Router();
const { grades, students, subjects } = require("../data");

function getNextId(items) {
  if (items.length === 0) return 1;
  return Math.max(...items.map((item) => item.id)) + 1;
}

router.get("/", (req, res) => res.json(grades));

router.post("/", (req, res) => {
  const { studentId, subjectId, value, date } = req.body;

  if (!studentId || !subjectId || !value || !date) {
    return res.status(400).json({ error: "Поля studentId, subjectId, value и date обязательны" });
  }
  if (value < 2 || value > 5) {
    return res.status(400).json({ error: "Оценка должна быть от 2 до 5" });
  }

  const student = students.find((s) => s.id === Number(studentId));
  const subject = subjects.find((s) => s.id === Number(subjectId));

  if (!student || !subject) {
    return res.status(404).json({ error: "Ученик или предмет не найден" });
  }

  const newGrade = {
    id: getNextId(grades),
    studentId: Number(studentId),
    subjectId: Number(subjectId),
    value: Number(value),
    date
  };

  grades.push(newGrade);
  res.status(201).json(newGrade);
});

//удалить
router.delete("/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = grades.findIndex((item) => item.id === id);

  if (index === -1) {
    return res.status(404).json({ error: "Оценка не найдена" });
  }

  const deleted = grades.splice(index, 1)[0];
  res.json({ message: "Оценка удалена", deleted });
});

module.exports = router;
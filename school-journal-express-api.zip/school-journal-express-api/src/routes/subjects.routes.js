const express = require("express");
const router = express.Router();
const { subjects } = require("../data");

function getNextId(items) {
  if (items.length === 0) return 1;
  return Math.max(...items.map((item) => item.id)) + 1;
}

router.get("/", (req, res) => {
  res.json(subjects);
});

router.post("/", (req, res) => {
  const { title } = req.body;
  if (!title) {
    return res.status(400).json({ error: "Поле title обязательно" });
  }
  const newSubject = { id: getNextId(subjects), title };
  subjects.push(newSubject);
  res.status(201).json(newSubject);
});

module.exports = router;
const express = require("express");
const router = express.Router();
const { students, subjects, grades } = require("../data");

router.get("/:className/journal", (req, res) => {
  const className = req.params.className;
  const classStudents = students.filter((item) => item.className === className);

  if (classStudents.length === 0) {
    return res.status(404).json({ error: "Класс не найден" });
  }

  const journal = classStudents.map((student) => {
    const studentGrades = grades
      .filter((grade) => grade.studentId === student.id)
      .map((grade) => {
        const subject = subjects.find((item) => item.id === grade.subjectId);
        return {
          subject: subject ? subject.title : "Предмет не найден",
          value: grade.value,
          date: grade.date
        };
      });
    return { student, grades: studentGrades };
  });

  res.json({ className, students: journal });
});

module.exports = router;
const express = require("express");
const router = express.Router();
const { students } = require("../data");

function getNextId(items) {
  if (items.length === 0) return 1;
  return Math.max(...items.map((item) => item.id)) + 1;
}


router.get("/", (req, res) => res.json(students));


router.get("/:id", (req, res) => {
  const id = Number(req.params.id);
  const student = students.find((item) => item.id === id);
  if (!student) return res.status(404).json({ error: "Ученик не найден" });
  res.json(student);
});


router.post("/", (req, res) => {
  const { lastName, firstName, className } = req.body;
  if (!lastName || !firstName || !className) {
    return res.status(400).json({ error: "Поля lastName, firstName и className обязательны" });
  }
  const newStudent = { id: getNextId(students), lastName, firstName, className };
  students.push(newStudent);
  res.status(201).json(newStudent);
});


router.put("/:id", (req, res) => {
  const id = Number(req.params.id);
  const student = students.find((item) => item.id === id);
  if (!student) return res.status(404).json({ error: "Ученик не найден" });

  student.lastName = req.body.lastName ?? student.lastName;
  student.firstName = req.body.firstName ?? student.firstName;
  student.className = req.body.className ?? student.className;

  res.json(student);
});


router.delete("/:id", (req, res) => {
  const id = Number(req.params.id);
  const index = students.findIndex((item) => item.id === id);
  if (index === -1) return res.status(404).json({ error: "Ученик не найден" });

  const deleted = students.splice(index, 1)[0];
  res.json({ message: "Ученик удален", deleted });
});

module.exports = router;
const students = [
    { id: 1, lastName: "Иванов", firstName: "Артем", className: "8А" },
    { id: 2, lastName: "Петрова", firstName: "Мария", className: "8А" },
    { id: 3, lastName: "Сидоров", firstName: "Денис", className: "9Б" }
];
const subjects = [
    { id: 1, title: "Информатика" },
    { id: 2, title: "Математика" },
    { id: 3, title: "Русский язык" }
];
const grades = [
    { id: 1, studentId: 1, subjectId: 1, value: 5, date: "2026-04-20" },
    { id: 2, studentId: 1, subjectId: 2, value: 4, date: "2026-04-21" },
    { id: 3, studentId: 2, subjectId: 1, value: 5, date: "2026-04-21" }
];
module.exports = { students, subjects, grades };
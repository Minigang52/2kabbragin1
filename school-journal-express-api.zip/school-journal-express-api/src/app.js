const express = require("express");
const cors = require("cors");
const swaggerUi = require("swagger-ui-express");
const swaggerDocument = require("./swagger.json");
const studentsRoutes = require("./routes/students.routes");
const subjectsRoutes = require("./routes/subjects.routes");
const gradesRoutes = require("./routes/grades.routes");
const journalRoutes = require("./routes/journal.routes");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.get("/health", (req, res) => {
  res.json({ status: "ok", message: "API школьного журнала работает" });
});

app.use("/api/students", studentsRoutes);
app.use("/api/subjects", subjectsRoutes);
app.use("/api/grades", gradesRoutes);
app.use("/api/classes", journalRoutes);

app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));

app.use((req, res) => {
  res.status(404).json({ error: "Маршрут не найден" });
});

app.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
  console.log(`Swagger: http://localhost:${PORT}/docs`);
});
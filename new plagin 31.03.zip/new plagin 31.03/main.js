document.getElementById('openAppBtn').addEventListener('click', () => {
  location.href='myapp://open';
});
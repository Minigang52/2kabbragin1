@echo off
setlocal
cd /d "%~dp0"

echo Enter full path to EXE file.
set "APP_PATH="
set /p APP_PATH=

if not exist "%APP_PATH%" (
  echo File not found: %APP_PATH%
  pause
  exit /b 1
)

> "%~dp0app_path.txt" echo %APP_PATH%

> "%~dp0index.html" (
  echo ^<!doctype html^>
  echo ^<html^>
  echo ^<head^>
  echo   ^<meta charset="utf-8"^>
  echo   ^<title^>Launch App^</title^>
  echo ^</head^>
  echo ^<body style="font-family:Arial;padding:40px"^>
  echo   ^<h2^>Launch App^</h2^>
  echo   ^<button onclick="location.href='myapp://open'" style="padding:12px 18px;font-size:16px;cursor:pointer"^>Open App^</button^>
  echo ^</body^>
  echo ^</html^>
)

reg add "HKCU\Software\Classes\myapp" /ve /d "URL:myapp" /f >nul
reg add "HKCU\Software\Classes\myapp" /v "URL Protocol" /d "" /f >nul
reg add "HKCU\Software\Classes\myapp\shell\open\command" /ve /d "\"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe\" -NoProfile -ExecutionPolicy Bypass -File \"%~dp0Launch-App.ps1\" \"%%1\"" /f >nul

echo.
echo Protocol myapp:// registered.
echo Open index.html and click the button.
pause

const clockEl = document.getElementById('clock');
const dateEl = document.getElementById('date');
const searchInput = document.getElementById('searchInput');
const addLinkBtn = document.getElementById('addLinkBtn');
const listLink = document.getElementById('listLink');
const noteEl = document.getElementById('note');
const saveNoteBtn = document.getElementById('saveNoteBtn');
const modal = document.getElementById('modal');
const linkTitle = document.getElementById('linkTitle');
const linkUrl = document.getElementById('linkUrl');
const saveLinkBtn = document.getElementById('saveLinkBtn');
const cancelModalBtn = document.getElementById('cancelModalBtn');

function updateClock() {
    const now = new Date();
    clockEl.textContent = now.toLocaleTimeString('ru-RU');
    dateEl.textContent = now.toLocaleDateString('ru-RU', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}
setInterval(updateClock, 1000);
updateClock();

searchInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
        const query = searchInput.value.trim();
        if (!query) return;
        window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    }
});

saveNoteBtn.addEventListener('click', () => {
    chrome.storage.local.set({ note: noteEl.value });
});

addLinkBtn.addEventListener('click', () => {
    linkTitle.value = '';
    linkUrl.value = '';
    modal.classList.remove('hidden');
});

cancelModalBtn.addEventListener('click', () => {
    modal.classList.add('hidden');
});





saveLinkBtn.addEventListener('click', () => {
    const title = linkTitle.value.trim();
    let url = linkUrl.value.trim();

    if (!title || !url) return;
    if (!/^https?:\/\//i.test(url)) {
        url = 'https://' + url;
    }


    chrome.storage.local.get(['links'], (result) => {
        const links = result.links || []; //poluchaem tekushiy spisok
        links.push({ title, url }); // add new ssilka
        chrome.storage.local.set({ links }, () => {
            renderLinks(links);
            modal.classList.add('hidden');
        });
    });
});





function renderLinks(links) {
    listLink.innerHTML = '';
    if (!links.length) {
        const empty = document.createElement('div');
        empty.className = 'empty-state';
        empty.textContent = 'Ссылок пока нет';
        listLink.appendChild(empty);
        return;
    }
    links.forEach((item, index) => {
        const card = document.createElement('div');
        card.className = 'link-card';

        // Создаем ссылку с иконкой
        const anchor = document.createElement('a');
        anchor.href = item.url;
        anchor.target = '_blank';
        anchor.style.display = 'flex';

        // Получаем домен с обработкой ошибок
        let domain;
        try {
            domain = new URL(item.url).hostname;
        } catch (e) {
            domain = item.url; // если не получилось, используем как есть
        }

        // Иконка через Google
        const favicon = document.createElement('img');
        favicon.src = `https://www.google.com/s2/favicons?domain=${domain}`;
        favicon.className = 'favicon';

        // Название
        const spanText = document.createElement('span');
        spanText.textContent = item.title;
        

        anchor.appendChild(favicon);
        anchor.appendChild(spanText);

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-link';
        deleteBtn.textContent = '×';
        deleteBtn.addEventListener('click', () => {
            chrome.storage.local.get(['links'], (result) => {
                const updated = result.links || [];
                updated.splice(index, 1);
                chrome.storage.local.set({ links: updated }, () => renderLinks(updated));
            });
        });

        card.appendChild(anchor);
        card.appendChild(deleteBtn);
        listLink.appendChild(card);
    });
}

function loadData() {
    chrome.storage.local.get(['note', 'links'], (result) => {
        noteEl.value = result.note || '';
        renderLinks(result.links || []);
    });
}
loadData();
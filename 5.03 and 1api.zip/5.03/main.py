from dotenv import load_dotenv
import os

load_dotenv()

secret_key = os.getenv('secret_key')
api_key = os.getenv('api_key')
lol_kek_chebyrnet = os.getenv('lol_kek_chebyrnet')

print(f"Secret Key: {secret_key}")
print(f"API Key: {api_key}")
print(f"INTERNET: {lol_kek_chebyrnet}")

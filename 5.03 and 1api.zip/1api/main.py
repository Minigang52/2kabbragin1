import requests
import xml.etree.ElementTree as ET

def fetch_and_parse_xml(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        root = ET.fromstring(response.content)
        return root
    except requests.RequestException as e:
        print(f"Ошибка запроса: {e}")
        return None
    except ET.ParseError:
        print("Ошибка парсинга XML")
        return None

def print_element(element, level=0):
    indent = "  " * level
    text = element.text.strip() if element.text else ''
    print(f"{indent}{element.tag}: {text}")
    for child in element:
        print_element(child, level + 1)

def api_1():
    url = 'http://www.cbr.ru/scripts/XML_daily.asp?date_req=02/03/2002'
    root = fetch_and_parse_xml(url)
    if root:
        for valute in root.findall('Valute'):
            char_code = valute.find('CharCode').text
            name = valute.find('Name').text
            value = valute.find('Value').text
            print(f"{name} ({char_code}): {value}")

def api_2():
    url = 'http://www.cbr.ru/scripts/XML_dynamic.asp?date_req1=02/03/2001&date_req2=14/03/2001&VAL_NM_RQ=R01235'
    root = fetch_and_parse_xml(url)
    if root:
        for record in root.findall('Record'):
            date = record.get('Date')
            value = record.find('Value').text
            print(f"Дата: {date}, Курс: {value}")

def api_3():
    url = "http://www.cbr.ru/scripts/XML_ostat.asp?date_req1=01/06/2001&date_req2=05/06/2001"
    root = fetch_and_parse_xml(url)
    if root:
        print_element(root)

def api_4():
    url = "http://www.cbr.ru/scripts/xml_metall.asp?date_req1=01/07/2001&date_req2=13/07/2001"
    root = fetch_and_parse_xml(url)
    if root:
        print_element(root)

def api_5():
    url = "http://www.cbr.ru/scripts/xml_mkr.asp?date_req1=01/07/2001&date_req2=13/07/2001"
    root = fetch_and_parse_xml(url)
    if root:
        print_element(root)

def api_6():
    url = "http://www.cbr.ru/scripts/xml_depo.asp?date_req1=01/07/2001&date_req2=13/07/2001"
    root = fetch_and_parse_xml(url)
    if root:
        print_element(root)

def api_7():
    url = "http://www.cbr.ru/scripts/XML_News.asp"
    root = fetch_and_parse_xml(url)
    if root:
        print_element(root)

def api_8():
    name = input("Введите название банка (например, 'АВТО'): ")
    bic = input("Введите BIC банка (например, '044525774'): ")
    url = f"http://www.cbr.ru/scripts/XML_bic.asp?name={name}&bic={bic}"
    root = fetch_and_parse_xml(url)
    if root:
        print_element(root)

def api_9():
    date_req1 = input("Введите начальную дату (дд/мм/гггг): ")
    date_req2 = input("Введите конечную дату (дд/мм/гггг): ")
    url = f"http://www.cbr.ru/scripts/XMLCoinsBase.asp?date_req1={date_req1}&date_req2={date_req2}"
    root = fetch_and_parse_xml(url)
    if root:
        print_element(root)

def main():
    print("Выберите API для загрузки данных:")
    print("1 - Обмен валют (XML_daily)")
    print("2 - Динамика курса (XML_dynamic)")
    print("3 - Остающиеся валюты (XML_ostat)")
    print("4 - Металлы (xml_metall)")
    print("5 - МКР (xml_mkr)")
    print("6 - Депозиты (xml_depo)")
    print("7 - Новости (XML_News)")
    print("8 - Информация по банкам (XML_bic)")
    print("9 - Курс монет (XMLCoinsBase)")
    choice = input("Введите номер (1-9): ")

    if choice == '1':
        api_1()
    elif choice == '2':
        api_2()
    elif choice == '3':
        api_3()
    elif choice == '4':
        api_4()
    elif choice == '5':
        api_5()
    elif choice == '6':
        api_6()
    elif choice == '7':
        api_7()
    elif choice == '8':
        api_8()
    elif choice == '9':
        api_9()
    else:
        print("Некорректный выбор.")

if __name__ == "__main__":
    main()
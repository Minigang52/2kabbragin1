const express = require('express');
const app = express();

app.use(express.json());


const teachers = [
  { id: 1, name: 'Иванова Мария Петровна', subject: 'Математика' },
  { id: 2, name: 'Петров Сергей Иванович', subject: 'Физика' },
  { id: 3, name: 'Сидорова Анна Владимировна', subject: 'Литература' }
];

const students = [
  { id: 1, name: 'Алексеев Дмитрий', grade: '5' },
  { id: 2, name: 'Борисова Елена', grade: '5' },
  { id: 3, name: 'Волков Иван', grade: '5' }
];

const food = [
  { id: 1, name: 'Борщ', price: 150},
  { id: 2, name: 'Котлета с пюре', price: 200},
  { id: 3, name: 'Чай', price: 50}
];

const grades = [
  { id: 1, studentName: 'Алексеев Дмитрий', subject: 'Математика', grade: 5},
  { id: 2, studentName: 'Борисова Елена', subject: 'Физика', grade: 4},
  { id: 3, studentName: 'Волков Иван', subject: 'Литература', grade: 5}
];

const guard = [
  { id: 1, name: 'Смирнов Петр', position: 'Старший охранник' },
  { id: 2, name: 'Козлов Андрей', position: 'Охранник'},
  { id: 3, name: 'Козлов sdjksdljk', position: 'Охранник'}
];


const administration = [
  { id: 1, name: 'Кузнецов Алексей Иванович', position: 'Директор' },
  { id: 2, name: 'Морозова Татьяна Сергеевна', position: 'Завуч' },
  { id: 3, name: 'Лебедев Игорь Петрович', position: 'Системный администратор' }
];


app.get('/', (req, res) => {
  res.send(`
    <h1>Школа</h1>

    <a href="/api/teachers">учителя</a><br>
    <a href="/api/students">ученики</a><br>
    <a href="/api/food">еда</a><br>
    <a href="/api/grades">оценки</a><br>
    <a href="/api/guard">охрана</a><br>
    <a href="/api/administration">администрация</a><br>


    <h3>Поиск по ID:</h3>

    <form id="searchForm" style="margin-bottom: 20px;">

      <select id="entity">
        <option value="students">Ученики</option>
        <option value="teachers">Учителя</option>
        <option value="food">Еда</option>
        <option value="grades">Оценки</option>
        <option value="guard">Охрана</option>
        <option value="administration">Администрация</option>
      </select>

      <input type="number" id="searchId" placeholder="Введите ID" required">
      <button type="submit">Найти</button>
    </form>


    <script>
      document.getElementById('searchForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const entity = document.getElementById('entity').value;
        const id = document.getElementById('searchId').value;
        window.location.href = '/api/' + entity + '/search/id?id=' + encodeURIComponent(id);
      });
    </script>
    
  `);
});


app.get('/api/teachers', (req, res) => res.json(teachers));
app.get('/api/students', (req, res) => res.json(students));
app.get('/api/food', (req, res) => res.json(food));
app.get('/api/grades', (req, res) => res.json(grades));
app.get('/api/guard', (req, res) => res.json(guard));
app.get('/api/administration', (req, res) => res.json(administration));



const searchById = (array, req, res, notFoundMsg) => {
  const id = parseInt(req.query.id);
  if (isNaN(id)) return res.status(400).json({ error: 'Укажите корректный ID в параметре ?id=...' });
  
  const found = array.find(item => item.id === id);
  if (found) {
    res.json(found);
  } else {
    res.status(404).json({ message: notFoundMsg });
  }
};




app.get('/api/students/search/id', (req, res) => searchById(students, req, res, 'Ученик не найден'));
app.get('/api/teachers/search/id', (req, res) => searchById(teachers, req, res, 'Учитель не найден'));
app.get('/api/food/search/id', (req, res) => searchById(food, req, res, 'Блюдо не найдено'));
app.get('/api/grades/search/id', (req, res) => searchById(grades, req, res, 'Запись об оценке не найдена'));
app.get('/api/guard/search/id', (req, res) => searchById(guard, req, res, 'Охранник не найден'));
app.get('/api/administration/search/id', (req, res) => searchById(administration, req, res, 'Сотрудник администрации не найден'));



app.listen(3000, () => {
  console.log('Сервер запущен на порту 3000');
});